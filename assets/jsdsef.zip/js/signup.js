var fname = document.getElementById('fname');
var mname = document.getElementById('mname');
var lname = document.getElementById('lname');
var gender = document.getElementById("gender");
var dob = document.getElementById('dob');

var email = document.getElementById('email');
var phnumber = document.getElementById('phnumber');
var fatname = document.getElementById('fatname');
var motname = document.getElementById("motname");
var state = document.getElementById('state');
var city = document.getElementById('city');

var mainclass = document.querySelectorAll("")

function regform(){
    
}

function borderColor(id){
    document.getElementById(id).style.borderColor = "#ff0000";
}
function setErrorMessage(id, msg){
    document.getElementById(id).innerHTML = msg;
    document.getElementById(id).style.color = "#ff0000";
}